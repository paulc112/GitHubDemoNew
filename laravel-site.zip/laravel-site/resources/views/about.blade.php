@extends ('layout')

@section('title', 'About us')


@section('content')

    
    <h1>About us</h1>

<p> Welcome to my Car website, here you can find lots of great cars.
</p>
 
</body>

</html>
@endsection
 