<?php $__env->startSection('title', 'About us'); ?>


<?php $__env->startSection('content'); ?>

    
    <h1>About us</h1>

<p> Welcome to my Car website, here you can find lots of great cars.
</p>
 
</body>

</html>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\paulm\Desktop\laravel-site\resources\views/about.blade.php ENDPATH**/ ?>