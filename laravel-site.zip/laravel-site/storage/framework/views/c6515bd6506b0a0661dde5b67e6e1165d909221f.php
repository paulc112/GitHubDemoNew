<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1 class="title">Cars</h1>
<ul>
    <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li>
        <a href="/cars/<?php echo e($car->id); ?>/edit">
        <?php echo e($car->model); ?> 
        </a>
        
        </li>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html><?php /**PATH C:\Users\paulm\Desktop\laravel-site\resources\views/cars/index.blade.php ENDPATH**/ ?>