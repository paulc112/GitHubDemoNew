<?php $__env->startSection('content'); ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Create a  New Project</h1>

   <form method="POST" action="/projects">
    <?php echo e(csrf_field()); ?>

    <div class="field"> 
        
        <label class="label" for="title">Project Title</label>
        <div class="control"> 
   
     <input type="text" class="input" name="title" required>
    </div>
 </div>
    <div class="field"> 
        
        <label class="label" for="description">Project Description</label>

        <div class="control">
        <textarea name="description" class="textarea" required></textarea>
    </div>
  <div>

  <div class="field"> 
  <div class="control"> 
        <button type="submit" class="button is-link">Create Project</button>
        </div>

        <div class="notification is-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
        </ul>
    </form>
</body>
<?php $__env->stopSection(); ?>
</html>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sites\laravel-site\resources\views/projects/create.blade.php ENDPATH**/ ?>