<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $__env->yieldContent('title', 'Laracasts'); ?> </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css">
    <script src="main.js"></script>
</head>
<body>
    <div class="container">
    <?php echo $__env->yieldContent('content'); ?>
    </div>
    <ul>
    <li><a href="/"> Home</a></li> 
    <li><a href="/about"> About</a></li> 
    <li><a href="/contact"> Contact</a></li> 
    <li><a href="/cars"> Cars</a></li> 
    <li><a href="/cars/create"> Update Cars</a></li> 
    <li><a href="/login"> Login or register</a></li>
    </ul> 
    
</body>

</html><?php /**PATH C:\Users\paulm\Desktop\laravel-site\resources\views/layout.blade.php ENDPATH**/ ?>