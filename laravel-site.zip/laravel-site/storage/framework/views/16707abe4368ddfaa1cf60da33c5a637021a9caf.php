<?php $__env->startSection('title', 'Contact Us'); ?>



<?php $__env->startSection('content'); ?>

    <h1>Contact Form </h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sites\laravel-site\resources\views/contact.blade.php ENDPATH**/ ?>