<?php $__env->startSection('title', 'About us'); ?>


<?php $__env->startSection('content'); ?>

    
    <h1>About us</h1>

<p> Welcome to my clothing store, here you can find lots of great products for you're everyday needs.
</p>
 
</body>

</html>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sites\laravel-site\resources\views/about.blade.php ENDPATH**/ ?>