<?php $__env->startSection('content'); ?>
    <h1 class="title"><?php echo e($project->title); ?></h1>

    <div class="content"><?php echo e($project->description); ?></div>

    <p>
        <a href="/projects/<?php echo e($project->id); ?>/edit">Edit</a>
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\paulm\Desktop\laravel-site\resources\views/projects/show.blade.php ENDPATH**/ ?>