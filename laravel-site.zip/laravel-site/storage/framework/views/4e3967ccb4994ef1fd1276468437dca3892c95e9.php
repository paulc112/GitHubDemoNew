<?php $__env->startSection('content'); ?>
    <h1 class="title">Edit Project</h1>

<form method="POST" action="/cars/<?php echo e($car->id); ?>" style="margin-bottom: 1em">
    <?php echo e(method_field('PATCH')); ?>

<div class="field">
    <label class="label" for="model">Car Model</label>
    <?php echo e(csrf_field()); ?>


    <div class="control">
        <input type="text" class="input" name="model" placeholder="Model" value="<?php echo e($car->model); ?>">
        </div>
    </div>

    <div class="field">
        <label class="label" for="color">Car Color</label>

        <div class="control">
            <textarea name="color" class="textarea"><?php echo e($car->color); ?></textarea>
        </div>
    </div>

    <div class="field">
        <div class="control">
            <button type="submit" class="button is-link">Update Car</button>
            </div>
        </div>
        </form>

<form method="POST" action="/cars/<?php echo e($car->id); ?>">
    <?php echo e(method_field('DELETE')); ?>

    <?php echo e(csrf_field()); ?>

    
        <div class="field">
        <div class="control">
            <button type="submit" class="button">Delete Car</button>
            </div>
        </div>

 </form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\paulm\Desktop\laravel-site\resources\views/cars/edit.blade.php ENDPATH**/ ?>