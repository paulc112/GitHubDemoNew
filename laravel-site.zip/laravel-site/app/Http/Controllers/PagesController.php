<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    
 public function home(){
    return view('welcome')->with([

        
        'foo' => 'Car',
        'tasks' => ['Here you can search car models and colors']
    ]);
 }
 public function contact(){
    return view('contact');
 }

 public function about(){
    return view('about');

        
 }
}

