<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Car;

class CarsController extends Controller
{
    public function index()
    {
        $cars = \App\Car::all();

        

        return view('cars.index', compact('cars'));
    }

public function create()
{
    return view('cars.create');
}

public function store()
{
    $car = new car();

    $car->model = request('model');
    $car->color = request('color');
    request()->validate([
        'model' => ['required', 'min:3'],
        'color' => ['required', 'min:3']
   ]);

   Cars::create(request(['model', 'color']));
    $car->save();
    return redirect('/cars');
}

public function edit(Car $car)
    {
        
        
       
         return view('cars.edit', compact('car'));
       
    }

    public function update(Car $car)
    {
        

        $car->model = request('model');
        $car->color = request('color');

        $car->save();

        return redirect('/cars');
    }
    public function destroy(Car $car)
    {
       $car->delete();

        return redirect('/cars');
    }
    
}